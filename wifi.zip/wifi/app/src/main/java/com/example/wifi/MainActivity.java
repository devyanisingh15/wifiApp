package com.example.wifi;

import android.content.Context;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button offbtn,onbtn,discoverbtn;
    ListView listView;
    WifiManager wifiManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        onbtn = findViewById(R.id.on_button);
        offbtn = findViewById(R.id.off_button);
        listView = findViewById(R.id.listView);

        wifiManager = (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        onbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wifiManager.setWifiEnabled(true);
            }
        });

        offbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wifiManager.setWifiEnabled(false);

            }
        });

        List<ScanResult> scanResults = wifiManager.getScanResults();
        ArrayList<String> nameArrayList = new ArrayList();
        for(ScanResult rs :scanResults){

            String name = rs.SSID;
            nameArrayList.add(name);
        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_list_item_1,nameArrayList);
        listView.setAdapter(arrayAdapter);
    }
}
